<?php

return [
    // URL catre query.php de pe hosting-ul tau
    'query_api_url'  => env('QUERY_API_URL', ''),
    'query_interval' => env('QUERY_INTERVAL_SECONDS', 60),
    'query_timeout'  => env('QUERY_TIMEOUT_SECONDS', 8),
    'query_batch'    => env('QUERY_BATCH_SIZE', 50),
];
