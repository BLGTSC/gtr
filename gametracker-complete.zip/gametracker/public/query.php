<?php
/**
 * GameTracker - query.php
 * ========================
 * Pune acest fisier in public_html pe hosting.
 * Acesta face query UDP real catre orice server de joc.
 *
 * Cerinte: PHP 7.4+, extensia sockets
 * URL: https://site-tau.ro/query.php?ip=89.42.132.29&port=27015
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Cache-Control: no-cache, no-store');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { exit(0); }

// ── Rate limiting simplu prin fisier ─────────────────────────────────────────
$rateFile = sys_get_temp_dir() . '/gt_rate_' . md5($_SERVER['REMOTE_ADDR'] ?? '');
$now      = time();
$calls    = [];
if (file_exists($rateFile)) {
    $calls = array_filter(json_decode(file_get_contents($rateFile), true) ?? [], fn($t) => $t > $now - 60);
}
if (count($calls) >= 30) {
    http_response_code(429);
    die(json_encode(['error' => 'Rate limit: max 30 query-uri/minut']));
}
$calls[] = $now;
file_put_contents($rateFile, json_encode(array_values($calls)));

// ── Validare ──────────────────────────────────────────────────────────────────
$ip   = trim($_GET['ip']   ?? '');
$port = (int)($_GET['port'] ?? 27015);

if (!filter_var($ip, FILTER_VALIDATE_IP)) {
    die(json_encode(['online' => false, 'error' => 'IP invalid']));
}
if ($port < 1 || $port > 65535) {
    die(json_encode(['online' => false, 'error' => 'Port invalid (1-65535)']));
}

// Blocheaza IP-uri private
foreach (['127.', '10.', '192.168.', '::1', 'localhost'] as $priv) {
    if (str_starts_with($ip, $priv) || $ip === $priv) {
        die(json_encode(['online' => false, 'error' => 'IP privat blocat']));
    }
}
for ($i = 16; $i <= 31; $i++) {
    if (str_starts_with($ip, "172.$i.")) {
        die(json_encode(['online' => false, 'error' => 'IP privat blocat']));
    }
}

// ── A2S_INFO Query ────────────────────────────────────────────────────────────
function a2sInfo(string $ip, int $port, int $timeout = 3): array
{
    if (!extension_loaded('sockets')) {
        throw new RuntimeException('Extensia PHP sockets nu este activata. Activeaz-o din cPanel → PHP Extensions.');
    }

    $sock = socket_create(AF_INET, SOCK_DGRAM, SOL_UDP);
    if ($sock === false) throw new RuntimeException('Nu pot crea socket UDP');

    socket_set_option($sock, SOL_SOCKET, SO_RCVTIMEO, ['sec' => $timeout, 'usec' => 0]);
    socket_set_option($sock, SOL_SOCKET, SO_SNDTIMEO, ['sec' => $timeout, 'usec' => 0]);

    // Trimite A2S_INFO
    $pkt = "\xFF\xFF\xFF\xFFTSource Engine Query\x00";
    $t0  = microtime(true);
    socket_sendto($sock, $pkt, strlen($pkt), 0, $ip, $port);

    $buf  = '';
    $from = ''; $fp = 0;
    $recv = @socket_recvfrom($sock, $buf, 4096, 0, $from, $fp);
    $ping = (int)round((microtime(true) - $t0) * 1000);
    socket_close($sock);

    if ($recv === false || strlen($buf) < 6) {
        return ['online' => false, 'ping' => $ping, 'error' => 'Server nu raspunde (offline sau firewall)'];
    }

    $off = 4;
    $type = ord($buf[$off++]);

    // Helper: citeste string null-terminated
    $str = function() use (&$buf, &$off): string {
        $e = strpos($buf, "\x00", $off);
        if ($e === false) { $s = substr($buf, $off); $off = strlen($buf); return $s; }
        $s = substr($buf, $off, $e - $off); $off = $e + 1; return $s;
    };
    $byte  = function() use (&$buf, &$off): int { return isset($buf[$off]) ? ord($buf[$off++]) : 0; };
    $short = function() use (&$buf, &$off): int { $v = unpack('v', substr($buf, $off, 2))[1] ?? 0; $off += 2; return $v; };

    if ($type === 0x49) {
        // Source protocol
        $byte();                   // protocol version
        $name    = $str();
        $map     = $str();
        $folder  = $str();
        $game    = $str();
        $appId   = $short();
        $players = $byte();
        $maxPl   = $byte();
        $bots    = $byte();
        $stype   = chr($byte());
        $os      = chr($byte());
        $passwd  = $byte();
        $vac     = $byte();
        $version = $str();
    } elseif ($type === 0x6D) {
        // GoldSrc protocol (CS 1.6)
        $str();                    // address
        $name    = $str();
        $map     = $str();
        $folder  = $str();
        $game    = $str();
        $players = $byte();
        $maxPl   = $byte();
        $byte();                   // protocol
        $stype   = chr($byte());
        $os      = chr($byte());
        $passwd  = $byte();
        $byte();                   // is_mod
        $vac     = $byte();
        $bots    = $byte();
        $appId   = 10;
        $version = '48/48';
    } else {
        return ['online' => false, 'error' => 'Protocol necunoscut: 0x' . dechex($type)];
    }

    $gameMap = [
        10 => 'Counter-Strike 1.6', 240 => 'Counter-Strike: Source',
        730 => 'Counter-Strike 2', 252490 => 'Rust', 346110 => 'ARK: Survival Evolved',
        107410 => 'Arma 3', 221100 => 'DayZ', 440 => 'Team Fortress 2',
        4000 => 'Garry\'s Mod', 1250410 => 'Squad',
    ];

    return [
        'online'             => true,
        'name'               => clean($name),
        'game'               => $gameMap[$appId] ?? clean($game),
        'map'                => clean($map),
        'gamemode'           => clean($game),
        'players_online'     => (int)($players ?? 0),
        'players_max'        => (int)($maxPl ?? 32),
        'bots'               => (int)($bots ?? 0),
        'ping'               => $ping,
        'version'            => clean($version ?? ''),
        'password_protected' => (bool)($passwd ?? false),
        'vac'                => (bool)($vac ?? false),
        'os'                 => (($os ?? 'l') === 'w') ? 'Windows' : 'Linux',
        'app_id'             => (int)($appId ?? 0),
        'players'            => [],
    ];
}

// ── A2S_PLAYER Query ──────────────────────────────────────────────────────────
function a2sPlayers(string $ip, int $port, int $timeout = 3): array
{
    if (!extension_loaded('sockets')) return [];

    $sock = socket_create(AF_INET, SOCK_DGRAM, SOL_UDP);
    if ($sock === false) return [];

    socket_set_option($sock, SOL_SOCKET, SO_RCVTIMEO, ['sec' => $timeout, 'usec' => 0]);
    socket_set_option($sock, SOL_SOCKET, SO_SNDTIMEO, ['sec' => $timeout, 'usec' => 0]);

    // Challenge request
    $from = ''; $fp = 0;
    socket_sendto($sock, "\xFF\xFF\xFF\xFF\x55\xFF\xFF\xFF\xFF", 9, 0, $ip, $port);
    $buf = ''; @socket_recvfrom($sock, $buf, 512, 0, $from, $fp);

    // Daca e challenge response
    if (strlen($buf) >= 9 && ord($buf[4]) === 0x41) {
        $challenge = substr($buf, 5, 4);
        socket_sendto($sock, "\xFF\xFF\xFF\xFF\x55" . $challenge, 9, 0, $ip, $port);
        $buf = ''; @socket_recvfrom($sock, $buf, 8192, 0, $from, $fp);
    }

    socket_close($sock);

    if (strlen($buf) < 6 || ord($buf[4]) !== 0x44) return [];

    $off     = 5;
    $count   = ord($buf[$off++]);
    $players = [];

    for ($i = 0; $i < $count && $off < strlen($buf); $i++) {
        $off++; // index
        $e    = strpos($buf, "\x00", $off);
        if ($e === false) break;
        $name = substr($buf, $off, $e - $off); $off = $e + 1;
        if ($off + 8 > strlen($buf)) break;
        $score    = unpack('l', substr($buf, $off, 4))[1]; $off += 4;
        $duration = unpack('f', substr($buf, $off, 4))[1]; $off += 4;

        $cleanName = clean($name);
        if ($cleanName === '') $cleanName = 'Player ' . ($i + 1);

        $players[] = [
            'name'  => $cleanName,
            'score' => max(0, (int)$score),
            'time'  => max(0, (int)$duration),
        ];
    }

    // Sorteaza dupa score descrescator
    usort($players, fn($a, $b) => $b['score'] <=> $a['score']);
    return $players;
}

// ── Curata string-uri ─────────────────────────────────────────────────────────
function clean(string $s): string
{
    $s = preg_replace('/\^[0-9]/', '', $s);              // Quake color codes
    $s = preg_replace('/\x1B\[[0-9;]*m/', '', $s);       // ANSI escape
    $s = preg_replace('/[\x00-\x1F\x7F\x80-\x9F]/', '', $s); // control chars
    return mb_substr(trim($s), 0, 100);
}

// ── Executa query ─────────────────────────────────────────────────────────────
try {
    $info = a2sInfo($ip, $port);

    if ($info['online'] && ($info['players_online'] ?? 0) > 0) {
        $info['players'] = a2sPlayers($ip, $port);
    }

    echo json_encode($info, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);

} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['online' => false, 'error' => $e->getMessage()]);
}
