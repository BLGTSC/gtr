/** @type {import('tailwindcss').Config} */
export default {
    darkMode: 'class',
    content: [
        './resources/views/**/*.blade.php',
        './resources/js/**/*.js',
        './app/Filament/**/*.php',
        './vendor/filament/**/*.blade.php',
    ],
    theme: {
        extend: {
            colors: {
                game: {
                    bg:      '#0a0d14',
                    surface: '#0f1320',
                    card:    '#161c2e',
                    border:  '#1e2640',
                    orange:  '#e8640c',
                    orange2: '#ff7a1a',
                    green:   '#22c55e',
                    red:     '#ef4444',
                    text:    '#e2e8f0',
                    muted:   '#6b7a9e',
                },
            },
            fontFamily: {
                sans:    ['Exo 2', 'system-ui', 'sans-serif'],
                display: ['Rajdhani', 'system-ui', 'sans-serif'],
                mono:    ['JetBrains Mono', 'monospace'],
            },
        },
    },
    plugins: [
        require('@tailwindcss/forms')({ strategy: 'class' }),
        require('@tailwindcss/typography'),
    ],
};
