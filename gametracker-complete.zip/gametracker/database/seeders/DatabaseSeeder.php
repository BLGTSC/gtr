<?php

namespace Database\Seeders;

use App\Models\Game;
use App\Models\Server;
use App\Models\ServerSnapshot;
use App\Models\Player;
use App\Models\User;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // Admin user
        User::factory()->create([
            'name'     => 'Admin',
            'email'    => env('ADMIN_EMAIL', 'admin@gametracker.com'),
            'password' => bcrypt(env('ADMIN_PASSWORD', 'password')),
        ]);

        // Jocuri suportate
        $games = [
            ['name'=>'Counter-Strike 1.6',   'short_name'=>'CS 1.6',  'protocol'=>'goldsrc',  'default_port'=>27015, 'sort_order'=>1],
            ['name'=>'Counter-Strike 2',      'short_name'=>'CS2',     'protocol'=>'source',   'default_port'=>27015, 'sort_order'=>2],
            ['name'=>'Garry\'s Mod',          'short_name'=>'GMod',    'protocol'=>'source',   'default_port'=>27015, 'sort_order'=>3],
            ['name'=>'Minecraft',             'short_name'=>'MC',      'protocol'=>'minecraft','default_port'=>25565, 'sort_order'=>4],
            ['name'=>'Rust',                  'short_name'=>'Rust',    'protocol'=>'source',   'default_port'=>28015, 'sort_order'=>5],
            ['name'=>'ARK: Survival Evolved', 'short_name'=>'ARK',     'protocol'=>'source',   'default_port'=>27015, 'sort_order'=>6],
            ['name'=>'DayZ',                  'short_name'=>'DayZ',    'protocol'=>'source',   'default_port'=>2302,  'sort_order'=>7],
            ['name'=>'FiveM',                 'short_name'=>'FiveM',   'protocol'=>'fivem',    'default_port'=>30120, 'sort_order'=>8],
        ];

        foreach ($games as $g) {
            Game::create(array_merge($g, ['is_active'=>true]));
        }

        // Servere demo cu istoric
        $gameModels = Game::all();
        $maps = ['de_dust2','de_inferno','cs_italy','de_aztec','fy_snow','zm_infected','jail_xmf','de_nuke'];
        $mods = ['Public','CSDM','Zombie Plague','GunGame','JailBreak','Surf'];
        $nicknames = ['xX_Mortis_Xx','RoManiaFTW','AWP.God.RO','GhostSniper','CsVeteran2003','ZeusKiller','n00bDestroyer','NightWolf_RO','HeadShot_King','BalaUR.CS'];

        foreach ($gameModels->take(3) as $game) {
            for ($s = 0; $s < 5; $s++) {
                $server = Server::create([
                    'game_id'         => $game->id,
                    'name'            => "[RO] SERVER-" . strtoupper($game->short_name) . "-" . ($s+1),
                    'ip'              => rand(1,254).'.'.rand(1,254).'.'.rand(1,254).'.'.rand(1,254),
                    'port'            => $game->default_port + $s,
                    'status'          => rand(0,3) > 0 ? 'online' : 'offline',
                    'players_online'  => rand(0, 28),
                    'players_max'     => [16,24,32][rand(0,2)],
                    'map'             => $maps[rand(0, count($maps)-1)],
                    'gamemode'        => $mods[rand(0, count($mods)-1)],
                    'ping'            => rand(10, 80),
                    'country_code'    => 'RO',
                    'is_active'       => true,
                    'is_featured'     => $s === 0,
                    'uptime_percentage' => rand(850, 999) / 10,
                    'first_seen_at'   => now()->subDays(rand(10, 180)),
                    'last_queried_at' => now()->subMinutes(rand(0, 5)),
                    'last_online_at'  => now()->subMinutes(rand(0, 30)),
                ]);

                // 7 zile de snapshot-uri pentru grafice
                for ($h = 168; $h >= 0; $h--) {
                    ServerSnapshot::create([
                        'server_id'      => $server->id,
                        'status'         => rand(1,20) > 1 ? 'online' : 'offline',
                        'players_online' => rand(0, 28),
                        'players_max'    => $server->players_max,
                        'ping'           => rand(10, 80),
                        'map'            => $server->map,
                        'queried_at'     => now()->subHours($h),
                    ]);
                }

                // Jucatori demo
                foreach (array_slice($nicknames, 0, rand(3, 8)) as $nick) {
                    Player::create([
                        'server_id'              => $server->id,
                        'name'                   => $nick,
                        'name_hash'              => md5(strtolower($nick)),
                        'total_sessions'         => rand(5, 200),
                        'total_playtime_minutes' => rand(60, 6000),
                        'total_kills'            => rand(50, 5000),
                        'total_deaths'           => rand(50, 3000),
                        'highest_score'          => rand(10, 80),
                        'first_seen_at'          => now()->subDays(rand(10, 90)),
                        'last_seen_at'           => now()->subHours(rand(1, 48)),
                    ]);
                }
            }
        }

        $this->command->info('Seeder complet! ' . Server::count() . ' servere create.');
    }
}
