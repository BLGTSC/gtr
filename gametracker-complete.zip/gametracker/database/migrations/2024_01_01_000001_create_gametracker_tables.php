<?php
// database/migrations/2024_01_01_000001_create_gametracker_tables.php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        // GAMES
        Schema::create('games', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('slug')->unique();
            $table->string('short_name', 20);
            $table->string('protocol', 50)->default('goldsrc');
            $table->unsignedSmallInteger('default_port')->nullable();
            $table->string('icon')->nullable();
            $table->text('description')->nullable();
            $table->boolean('is_active')->default(true);
            $table->integer('sort_order')->default(0);
            $table->timestamps();
        });

        // SERVERS
        Schema::create('servers', function (Blueprint $table) {
            $table->id();
            $table->foreignId('game_id')->constrained()->cascadeOnDelete();
            $table->foreignId('user_id')->nullable()->constrained()->nullOnDelete();
            $table->string('name');
            $table->string('slug')->unique();
            $table->string('ip', 45);
            $table->unsignedSmallInteger('port');
            $table->text('description')->nullable();
            $table->string('website')->nullable();
            $table->string('country_code', 2)->nullable();
            // Status curent
            $table->enum('status', ['online','offline','unknown'])->default('unknown');
            $table->string('map', 100)->nullable();
            $table->string('gamemode', 100)->nullable();
            $table->unsignedSmallInteger('players_online')->default(0);
            $table->unsignedSmallInteger('players_max')->default(0);
            $table->unsignedSmallInteger('ping')->nullable();
            $table->string('version', 50)->nullable();
            $table->string('server_name', 200)->nullable();
            $table->boolean('has_password')->default(false);
            $table->boolean('vac')->default(false);
            $table->json('extra_info')->nullable();
            // Statistici
            $table->unsignedBigInteger('total_queries')->default(0);
            $table->unsignedBigInteger('failed_queries')->default(0);
            $table->float('uptime_percentage', 5, 2)->default(0);
            $table->unsignedInteger('peak_players')->default(0);
            $table->timestamp('peak_players_at')->nullable();
            $table->unsignedInteger('favorites_count')->default(0);
            // Flags
            $table->boolean('is_active')->default(true);
            $table->boolean('is_featured')->default(false);
            $table->boolean('is_verified')->default(false);
            $table->timestamp('last_queried_at')->nullable();
            $table->timestamp('last_online_at')->nullable();
            $table->timestamp('first_seen_at')->nullable();
            $table->timestamps();
            $table->softDeletes();
            $table->unique(['ip','port']);
            $table->index(['game_id','status','players_online']);
            $table->index('last_queried_at');
        });

        // SNAPSHOTS (istoric pentru grafice)
        Schema::create('server_snapshots', function (Blueprint $table) {
            $table->id();
            $table->foreignId('server_id')->constrained()->cascadeOnDelete();
            $table->enum('status', ['online','offline'])->default('online');
            $table->unsignedSmallInteger('players_online')->default(0);
            $table->unsignedSmallInteger('players_max')->default(0);
            $table->unsignedSmallInteger('ping')->nullable();
            $table->string('map', 100)->nullable();
            $table->string('gamemode', 100)->nullable();
            $table->unsignedInteger('query_duration_ms')->nullable();
            $table->timestamp('queried_at');
            $table->index(['server_id','queried_at']);
        });

        // PLAYERS
        Schema::create('players', function (Blueprint $table) {
            $table->id();
            $table->foreignId('server_id')->constrained()->cascadeOnDelete();
            $table->string('name', 64);
            $table->string('name_hash', 32)->nullable();
            $table->string('steam_id', 30)->nullable();
            $table->unsignedBigInteger('total_sessions')->default(0);
            $table->unsignedBigInteger('total_playtime_minutes')->default(0);
            $table->unsignedInteger('total_kills')->default(0);
            $table->unsignedInteger('total_deaths')->default(0);
            $table->unsignedInteger('highest_score')->default(0);
            $table->timestamp('first_seen_at')->nullable();
            $table->timestamp('last_seen_at')->nullable();
            $table->timestamps();
            $table->unique(['server_id','name_hash']);
        });

        // PLAYER SESSIONS
        Schema::create('player_sessions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('player_id')->constrained()->cascadeOnDelete();
            $table->foreignId('server_id')->constrained()->cascadeOnDelete();
            $table->string('name_at_time', 64);
            $table->unsignedSmallInteger('score')->default(0);
            $table->unsignedSmallInteger('kills')->default(0);
            $table->unsignedSmallInteger('deaths')->default(0);
            $table->unsignedInteger('duration_minutes')->default(0);
            $table->string('map_at_time', 100)->nullable();
            $table->timestamp('started_at');
            $table->timestamp('ended_at')->nullable();
            $table->boolean('is_active')->default(true);
            $table->index(['server_id','is_active']);
        });

        // SETTINGS (admin editabil)
        Schema::create('settings', function (Blueprint $table) {
            $table->id();
            $table->string('key', 100)->unique();
            $table->text('value')->nullable();
            $table->string('type', 20)->default('string');
            $table->string('group', 50)->default('general');
            $table->string('label')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('player_sessions');
        Schema::dropIfExists('players');
        Schema::dropIfExists('server_snapshots');
        Schema::dropIfExists('servers');
        Schema::dropIfExists('games');
        Schema::dropIfExists('settings');
    }
};
