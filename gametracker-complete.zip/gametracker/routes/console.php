<?php

use Illuminate\Support\Facades\Schedule;

// Query servere la fiecare 60 secunde
Schedule::command('gametracker:query')
    ->everyMinute()
    ->withoutOverlapping(5)
    ->runInBackground();

// Sterge snapshot-uri mai vechi de 90 zile
Schedule::command('gametracker:prune-snapshots --days=90')
    ->daily()
    ->at('03:00');

// Regenereaza sitemap zilnic
Schedule::command('sitemap:generate')
    ->daily()
    ->at('02:00');
