<?php

use App\Http\Controllers\ServerController;
use App\Http\Controllers\HomeController;
use Illuminate\Support\Facades\Route;

// ── Publice ───────────────────────────────────────────────────────────────────
Route::get('/', [HomeController::class, 'index'])->name('home');
Route::get('/servers', [ServerController::class, 'index'])->name('servers.index');
Route::get('/servers/{server:slug}', [ServerController::class, 'show'])->name('servers.show');

// ── Autentificat ──────────────────────────────────────────────────────────────
Route::middleware('auth')->group(function () {
    Route::get('/add-server',  [ServerController::class, 'create'])->name('servers.create');
    Route::post('/add-server', [ServerController::class, 'store'])->name('servers.store');
});

// ── API JSON ──────────────────────────────────────────────────────────────────
Route::prefix('api')->name('api.')->group(function () {
    // Query instant - apelat din frontend cu IP:port
    Route::post('/query', [ServerController::class, 'queryInstant'])
        ->middleware('throttle:30,1')
        ->name('query');

    Route::get('/servers/{server:slug}/live',  [ServerController::class, 'liveData'])->name('servers.live');
    Route::get('/servers/{server:slug}/chart', [ServerController::class, 'chartData'])->name('servers.chart');
});

// ── Auth (Breeze) ─────────────────────────────────────────────────────────────
require __DIR__.'/auth.php';
