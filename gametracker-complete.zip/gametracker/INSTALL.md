# GameTracker — Ghid Instalare Complet

## Cerințe sistem
- PHP 8.2+ cu extensiile: `sockets`, `bcmath`, `ctype`, `curl`, `json`, `mbstring`, `openssl`, `pdo_mysql`, `tokenizer`
- Composer 2.x
- Node.js 18+ & npm
- MySQL 8.0 / MariaDB 10.11+
- Redis 7+ (recomandat) sau database queue driver

---

## Pasul 1 — Clonează / uploadează proiectul

```bash
git clone https://github.com/youruser/gametracker.git
cd gametracker
```

## Pasul 2 — Instalare dependențe

```bash
composer install --optimize-autoloader --no-dev
npm install && npm run build
```

## Pasul 3 — Configurare `.env`

```bash
cp .env.example .env
php artisan key:generate
```

Editează `.env`:
```env
APP_URL=https://site-tau.ro

DB_DATABASE=gametracker
DB_USERNAME=user
DB_PASSWORD=parola

# CRUCIAL: URL-ul catre query.php
QUERY_API_URL=https://site-tau.ro/query.php

QUEUE_CONNECTION=redis
CACHE_DRIVER=redis
SESSION_DRIVER=redis

REDIS_HOST=127.0.0.1
REDIS_PORT=6379
```

## Pasul 4 — Baza de date

```bash
php artisan migrate --force
php artisan db:seed   # date demo (optional)
```

## Pasul 5 — Instalare query.php

**Aceasta este cea mai importantă parte!**

1. Copiază `public/query.php` pe hosting-ul tău în `public_html/`
2. Verifică că extensia `sockets` e activată în PHP:
   - cPanel → PHP Selector → Extensions → bifează `sockets`
   - SAU în `php.ini`: `extension=sockets`
3. Testează în browser:
   ```
   https://site-tau.ro/query.php?ip=89.42.132.29&port=27015
   ```
   Ar trebui să returneze JSON cu datele serverului.

4. Setează URL-ul în `.env`:
   ```env
   QUERY_API_URL=https://site-tau.ro/query.php
   ```

## Pasul 6 — Permisiuni

```bash
chmod -R 775 storage bootstrap/cache
chown -R www-data:www-data storage bootstrap/cache
php artisan storage:link
```

## Pasul 7 — Cron (Scheduler)

Adaugă în crontab (`crontab -e`):
```
* * * * * cd /var/www/gametracker && php artisan schedule:run >> /dev/null 2>&1
```

## Pasul 8 — Queue Worker (VPS)

**Supervisor config** (`/etc/supervisor/conf.d/gametracker.conf`):
```ini
[program:gametracker-worker]
process_name=%(program_name)s_%(process_num)02d
command=php /var/www/gametracker/artisan queue:work redis --queue=queries,default --sleep=3 --tries=3
autostart=true
autorestart=true
numprocs=2
user=www-data
redirect_stderr=true
stdout_logfile=/var/log/gametracker-worker.log
```

```bash
supervisorctl reread && supervisorctl update && supervisorctl start gametracker-worker:*
```

**Pe shared hosting** (fara Supervisor), foloseste un cron job la fiecare minut:
```
* * * * * cd /var/www/html && php artisan queue:work --stop-when-empty --queue=queries,default >> /dev/null 2>&1
```

## Pasul 9 — Admin Panel

URL: `https://site-tau.ro/admin`

Credentials din `.env`:
```env
ADMIN_EMAIL=admin@gametracker.com
ADMIN_PASSWORD=change_me_immediately
```

### Ce poți face din Admin:
- **Servere** — editează, șterge, forțează query instant
- **Utilizatori** — editează, schimbă roluri
- **Setări → nav_links** — editează butoanele din navbar (JSON array):
  ```json
  [
    {"label": "Home", "url": "/"},
    {"label": "Servere", "url": "/servers"},
    {"label": "Statistici", "url": "/stats"}
  ]
  ```

## Pasul 10 — Optimizări producție

```bash
php artisan config:cache
php artisan route:cache
php artisan view:cache
php artisan icons:cache
php artisan filament:upgrade
```

---

## Structura fișiere cheie

```
gametracker/
├── public/
│   └── query.php              ← PUNE ASTA PE HOSTING (face query UDP real)
├── app/
│   ├── Services/
│   │   └── GameQueryService.php  ← Apeleaza query.php API
│   ├── Jobs/
│   │   └── QueryServerJob.php    ← Ruleaza la fiecare 60s via Queue
│   ├── Models/
│   │   ├── Server.php
│   │   ├── Game.php
│   │   ├── Player.php
│   │   ├── PlayerSession.php
│   │   ├── ServerSnapshot.php
│   │   └── Setting.php           ← Include nav_links editabile
│   ├── Http/Controllers/
│   │   └── ServerController.php  ← Include /api/query endpoint
│   └── Filament/Resources/
│       ├── ServerResource.php    ← Admin: servere
│       ├── UserResource.php      ← Admin: utilizatori
│       └── SettingResource.php   ← Admin: setari + nav links
├── resources/views/
│   ├── layouts/app.blade.php     ← Layout principal cu navbar
│   └── pages/servers/
│       ├── index.blade.php       ← Lista servere
│       ├── show.blade.php        ← Pagina server (grafic, jucatori)
│       └── create.blade.php      ← Adauga server cu query live
├── routes/
│   ├── web.php
│   └── console.php              ← Scheduler
└── config/
    └── gametracker.php
```

---

## Flux query live (adăugare server)

```
Browser → POST /api/query → GameQueryService → query.php (hosting) → UDP → Server CS
                                                    ↓
                                             JSON cu date reale
                                                    ↓
Browser ← afișare: nume real, hartă reală, jucători reali
```

---

## Troubleshooting

**"QUERY_API_URL nu este setat"** → Setează `QUERY_API_URL` în `.env`

**"Extensia PHP sockets nu este activată"** → Activează `sockets` în cPanel → PHP Extensions

**"Server nu răspunde"** → Serverul poate fi offline sau are firewall pe UDP. Testează manual:
```bash
php -r "
\$s = socket_create(AF_INET, SOCK_DGRAM, SOL_UDP);
socket_set_option(\$s, SOL_SOCKET, SO_RCVTIMEO, ['sec'=>3,'usec'=>0]);
socket_sendto(\$s, \"\\xFF\\xFF\\xFF\\xFFTSource Engine Query\\x00\", 25, 0, '89.42.132.29', 27015);
\$r=''; socket_recvfrom(\$s, \$r, 4096, 0, \$f, \$p);
echo strlen(\$r) > 10 ? 'OK: '.strlen(\$r).' bytes' : 'FAIL';
"
```

**Admin panel gol** → `php artisan filament:upgrade && php artisan icons:cache`
