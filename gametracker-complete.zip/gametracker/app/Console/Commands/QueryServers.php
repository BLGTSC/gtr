<?php

namespace App\Console\Commands;

use App\Jobs\QueryServerJob;
use App\Models\Server;
use Illuminate\Console\Command;

class QueryServers extends Command
{
    protected $signature   = 'gametracker:query {--force : Query toate, indiferent de interval}';
    protected $description = 'Dispatch QueryServerJob pentru serverele care au nevoie de query';

    public function handle(): int
    {
        $query = Server::active()->with('game')
            ->when(!$this->option('force'), fn($q) => $q->needsQuery());

        $count = 0;
        $query->chunkById(50, function ($servers) use (&$count) {
            foreach ($servers as $server) {
                QueryServerJob::dispatch($server);
                $count++;
            }
        });

        $this->info("Dispatched {$count} query jobs.");
        return Command::SUCCESS;
    }
}
