<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class PlayerSession extends Model
{
    protected $fillable = [
        'player_id','server_id','name_at_time','score','kills',
        'deaths','duration_minutes','map_at_time','started_at','ended_at','is_active',
    ];
    protected $casts = [
        'started_at' => 'datetime',
        'ended_at'   => 'datetime',
        'is_active'  => 'boolean',
    ];
    public function player(): BelongsTo { return $this->belongsTo(Player::class); }
    public function server(): BelongsTo { return $this->belongsTo(Server::class); }
}
