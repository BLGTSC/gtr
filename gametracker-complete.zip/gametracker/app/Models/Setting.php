<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Cache;

class Setting extends Model
{
    protected $fillable = ['key', 'value', 'type', 'group', 'label'];

    public static function get(string $key, mixed $default = null): mixed
    {
        return Cache::remember("setting_{$key}", 300, function () use ($key, $default) {
            $s = static::where('key', $key)->first();
            return $s ? $s->value : $default;
        });
    }

    public static function set(string $key, mixed $value): void
    {
        static::updateOrCreate(['key' => $key], ['value' => $value]);
        Cache::forget("setting_{$key}");
        Cache::forget('nav_links');
    }

    /**
     * Returneaza link-urile din navbar (editabile din admin).
     */
    public static function getNavLinks(): array
    {
        return Cache::remember('nav_links', 300, function () {
            $raw = static::where('key', 'nav_links')->value('value');
            if ($raw) {
                $decoded = json_decode($raw, true);
                if (is_array($decoded)) return $decoded;
            }
            // Default
            return [
                ['label' => 'Home',       'url' => '/'],
                ['label' => 'Servere',    'url' => '/servers'],
                ['label' => 'Statistici', 'url' => '/stats'],
                ['label' => 'Noutăți',    'url' => '/news'],
            ];
        });
    }
}
