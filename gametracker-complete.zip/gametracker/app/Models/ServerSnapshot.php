<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class ServerSnapshot extends Model
{
    public $timestamps = false;
    protected $fillable = [
        'server_id','status','players_online','players_max',
        'ping','map','gamemode','query_duration_ms','queried_at',
    ];
    protected $casts = ['queried_at' => 'datetime'];
    public function server(): BelongsTo { return $this->belongsTo(Server::class); }

    public static function hourlyAverages(int $serverId, int $hours = 24): array
    {
        return static::where('server_id', $serverId)
            ->where('queried_at', '>=', now()->subHours($hours))
            ->selectRaw('DATE_FORMAT(queried_at,"%Y-%m-%d %H:00:00") as hour, ROUND(AVG(players_online)) as avg_players, MAX(players_online) as max_players, COUNT(*) as queries')
            ->groupByRaw('DATE_FORMAT(queried_at,"%Y-%m-%d %H:00:00")')
            ->orderBy('hour')->get()->toArray();
    }
}
