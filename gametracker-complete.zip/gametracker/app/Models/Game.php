<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Spatie\Sluggable\HasSlug;
use Spatie\Sluggable\SlugOptions;

class Game extends Model
{
    use HasFactory, HasSlug;

    protected $fillable = [
        'name', 'slug', 'short_name', 'protocol',
        'default_port', 'icon', 'description',
        'is_active', 'sort_order',
    ];

    protected $casts = ['is_active' => 'boolean'];

    public function servers(): HasMany  { return $this->hasMany(Server::class); }
    public function activeServers(): HasMany { return $this->hasMany(Server::class)->where('is_active', true); }

    public function getSlugOptions(): SlugOptions
    {
        return SlugOptions::create()->generateSlugsFrom('name')->saveSlugsTo('slug');
    }

    public function getRouteKeyName(): string { return 'slug'; }

    public function scopeActive($q) { return $q->where('is_active', true)->orderBy('sort_order'); }
}
