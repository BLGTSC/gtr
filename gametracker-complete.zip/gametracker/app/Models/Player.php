<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Player extends Model
{
    protected $fillable = [
        'server_id','name','name_hash','steam_id',
        'total_sessions','total_playtime_minutes',
        'total_kills','total_deaths','highest_score',
        'first_seen_at','last_seen_at',
    ];
    protected $casts = ['first_seen_at' => 'datetime', 'last_seen_at' => 'datetime'];

    public function server(): BelongsTo { return $this->belongsTo(Server::class); }
    public function sessions(): HasMany { return $this->hasMany(PlayerSession::class)->latest('started_at'); }

    public function getKdRatioAttribute(): float
    {
        if (!$this->total_deaths) return (float)$this->total_kills;
        return round($this->total_kills / $this->total_deaths, 2);
    }

    public function getPlaytimeFormattedAttribute(): string
    {
        $h = intdiv($this->total_playtime_minutes, 60);
        $m = $this->total_playtime_minutes % 60;
        return $h > 0 ? "{$h}h {$m}m" : "{$m}m";
    }

    public static function findOrCreateFromSession(int $serverId, string $name): static
    {
        $hash = md5(strtolower(trim($name)));
        return static::firstOrCreate(
            ['server_id' => $serverId, 'name_hash' => $hash],
            ['name' => $name, 'first_seen_at' => now(), 'last_seen_at' => now()]
        );
    }
}
