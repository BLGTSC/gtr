<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;
use Spatie\Sluggable\HasSlug;
use Spatie\Sluggable\SlugOptions;

class Server extends Model
{
    use HasFactory, HasSlug, SoftDeletes;

    protected $fillable = [
        'game_id', 'user_id', 'name', 'slug', 'ip', 'port',
        'description', 'website', 'country_code',
        'status', 'map', 'gamemode', 'players_online', 'players_max',
        'ping', 'version', 'server_name', 'has_password', 'vac',
        'extra_info', 'total_queries', 'failed_queries', 'uptime_percentage',
        'peak_players', 'peak_players_at', 'favorites_count',
        'is_active', 'is_featured', 'is_verified',
        'last_queried_at', 'last_online_at', 'first_seen_at',
    ];

    protected $casts = [
        'has_password'      => 'boolean',
        'vac'               => 'boolean',
        'is_active'         => 'boolean',
        'is_featured'       => 'boolean',
        'is_verified'       => 'boolean',
        'extra_info'        => 'array',
        'peak_players_at'   => 'datetime',
        'last_queried_at'   => 'datetime',
        'last_online_at'    => 'datetime',
        'first_seen_at'     => 'datetime',
        'uptime_percentage' => 'float',
    ];

    // ── Relationships ─────────────────────────────────────────────────────────

    public function game(): BelongsTo { return $this->belongsTo(Game::class); }
    public function owner(): BelongsTo { return $this->belongsTo(User::class, 'user_id'); }
    public function snapshots(): HasMany { return $this->hasMany(ServerSnapshot::class)->latest('queried_at'); }
    public function players(): HasMany { return $this->hasMany(Player::class); }
    public function playerSessions(): HasMany { return $this->hasMany(PlayerSession::class); }

    // ── Slug ──────────────────────────────────────────────────────────────────

    public function getSlugOptions(): SlugOptions
    {
        return SlugOptions::create()
            ->generateSlugsFrom(fn($m) => ($m->game->short_name ?? 'srv') . '-' . $m->ip . '-' . $m->port)
            ->saveSlugsTo('slug')
            ->slugsShouldBeNoLongerThan(80);
    }

    public function getRouteKeyName(): string { return 'slug'; }

    // ── Scopes ────────────────────────────────────────────────────────────────

    public function scopeActive($q)   { return $q->where('is_active', true); }
    public function scopeOnline($q)   { return $q->where('status', 'online'); }
    public function scopeFeatured($q) { return $q->where('is_featured', true); }

    public function scopeNeedsQuery($q)
    {
        $interval = config('gametracker.query_interval', 60);
        return $q->where('is_active', true)
            ->where(fn($s) => $s->whereNull('last_queried_at')
                ->orWhere('last_queried_at', '<=', now()->subSeconds($interval)));
    }

    // ── Accessors ─────────────────────────────────────────────────────────────

    public function getAddressAttribute(): string { return "{$this->ip}:{$this->port}"; }
    public function getIsOnlineAttribute(): bool  { return $this->status === 'online'; }

    public function getPlayersFillPercentAttribute(): int
    {
        if (!$this->players_max) return 0;
        return (int) round($this->players_online / $this->players_max * 100);
    }

    // ── Methods ───────────────────────────────────────────────────────────────

    public function markOnline(array $data): void
    {
        $this->fill([
            'status'         => 'online',
            'server_name'    => $data['name']               ?? $this->server_name,
            'map'            => $data['map']                ?? null,
            'gamemode'       => $data['gamemode']           ?? null,
            'players_online' => $data['players_online']     ?? 0,
            'players_max'    => $data['players_max']        ?? 0,
            'ping'           => $data['ping']               ?? null,
            'version'        => $data['version']            ?? null,
            'has_password'   => $data['password_protected'] ?? false,
            'vac'            => $data['vac']                ?? false,
            'last_queried_at'=> now(),
            'last_online_at' => now(),
            'total_queries'  => $this->total_queries + 1,
        ]);

        if (($data['players_online'] ?? 0) > $this->peak_players) {
            $this->peak_players    = $data['players_online'];
            $this->peak_players_at = now();
        }

        $this->save();
    }

    public function markOffline(string $error = ''): void
    {
        $this->update([
            'status'          => 'offline',
            'last_queried_at' => now(),
            'total_queries'   => $this->total_queries + 1,
            'failed_queries'  => $this->failed_queries + 1,
        ]);
    }
}
