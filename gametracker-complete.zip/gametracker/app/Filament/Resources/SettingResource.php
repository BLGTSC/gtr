<?php

namespace App\Filament\Resources;

use App\Models\Setting;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Support\Facades\Cache;

class SettingResource extends Resource
{
    protected static ?string $model = Setting::class;
    protected static ?string $navigationIcon  = 'heroicon-o-cog-6-tooth';
    protected static ?string $navigationGroup = 'Sistem';
    protected static ?string $navigationLabel = 'Setări';
    protected static ?int    $navigationSort  = 10;

    public static function form(Form $form): Form
    {
        return $form->schema([
            Forms\Components\TextInput::make('key')->required()->label('Cheie'),
            Forms\Components\TextInput::make('label')->label('Etichetă'),
            Forms\Components\Select::make('group')
                ->options(['general'=>'General','nav'=>'Navigare','seo'=>'SEO','query'=>'Query'])
                ->default('general')->label('Grup'),
            Forms\Components\Textarea::make('value')->rows(4)->label('Valoare'),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('key')->searchable()->label('Cheie'),
                Tables\Columns\TextColumn::make('label')->label('Etichetă'),
                Tables\Columns\TextColumn::make('group')->badge()->label('Grup'),
                Tables\Columns\TextColumn::make('value')->limit(60)->label('Valoare'),
            ])
            ->actions([
                Tables\Actions\EditAction::make()
                    ->after(fn() => Cache::flush()),
            ]);
    }

    public static function getPages(): array
    {
        return [
            'index' => \App\Filament\Resources\SettingResource\Pages\ListSettings::route('/'),
            'edit'  => \App\Filament\Resources\SettingResource\Pages\EditSetting::route('/{record}/edit'),
        ];
    }
}
