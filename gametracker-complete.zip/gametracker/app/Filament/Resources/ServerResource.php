<?php

namespace App\Filament\Resources;

use App\Filament\Resources\ServerResource\Pages;
use App\Models\Server;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;

class ServerResource extends Resource
{
    protected static ?string $model = Server::class;
    protected static ?string $navigationIcon  = 'heroicon-o-server';
    protected static ?string $navigationGroup = 'Game Servers';
    protected static ?string $navigationLabel = 'Servere';
    protected static ?int    $navigationSort  = 1;

    public static function form(Form $form): Form
    {
        return $form->schema([
            Forms\Components\Section::make('Identificare')->schema([
                Forms\Components\TextInput::make('ip')->required()->label('IP Address'),
                Forms\Components\TextInput::make('port')->required()->numeric()->minValue(1)->maxValue(65535),
                Forms\Components\Select::make('game_id')->relationship('game', 'name')->searchable()->required()->label('Joc'),
                Forms\Components\TextInput::make('name')->required()->maxLength(200)->label('Nume afișat'),
            ])->columns(2),

            Forms\Components\Section::make('Status')->schema([
                Forms\Components\Select::make('status')->options(['online'=>'Online','offline'=>'Offline','unknown'=>'Unknown'])->default('unknown'),
                Forms\Components\TextInput::make('map')->label('Hartă curentă'),
                Forms\Components\TextInput::make('players_online')->numeric()->default(0),
                Forms\Components\TextInput::make('players_max')->numeric()->default(32),
                Forms\Components\TextInput::make('ping')->numeric()->nullable(),
            ])->columns(3),

            Forms\Components\Section::make('Setări')->schema([
                Forms\Components\Toggle::make('is_active')->label('Activ')->default(true),
                Forms\Components\Toggle::make('is_featured')->label('Featured'),
                Forms\Components\Toggle::make('is_verified')->label('Verificat'),
            ])->columns(3),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('name')->searchable()->limit(40)->label('Nume'),
                Tables\Columns\TextColumn::make('address')->label('IP:Port')->fontFamily('mono'),
                Tables\Columns\TextColumn::make('game.short_name')->badge()->label('Joc'),
                Tables\Columns\BadgeColumn::make('status')
                    ->colors(['success'=>'online','danger'=>'offline','warning'=>'unknown'])
                    ->label('Status'),
                Tables\Columns\TextColumn::make('players_online')->label('Jucători')
                    ->formatStateUsing(fn($state, $record) => "{$state}/{$record->players_max}"),
                Tables\Columns\TextColumn::make('uptime_percentage')->label('Uptime')->suffix('%'),
                Tables\Columns\TextColumn::make('last_queried_at')->since()->label('Ultima verificare'),
                Tables\Columns\IconColumn::make('is_active')->boolean()->label('Activ'),
                Tables\Columns\IconColumn::make('is_featured')->boolean()->label('Featured'),
            ])
            ->filters([
                Tables\Filters\SelectFilter::make('status')->options(['online'=>'Online','offline'=>'Offline']),
                Tables\Filters\SelectFilter::make('game_id')->relationship('game','name')->label('Joc'),
                Tables\Filters\TernaryFilter::make('is_featured')->label('Featured'),
            ])
            ->actions([
                Tables\Actions\Action::make('query_now')
                    ->icon('heroicon-o-arrow-path')
                    ->label('Query acum')
                    ->action(fn(Server $record) => \App\Jobs\QueryServerJob::dispatch($record))
                    ->color('warning'),
                Tables\Actions\EditAction::make(),
                Tables\Actions\DeleteAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                    Tables\Actions\BulkAction::make('query_selected')
                        ->label('Query selectate')
                        ->icon('heroicon-o-arrow-path')
                        ->action(fn($records) => $records->each(fn($r) => \App\Jobs\QueryServerJob::dispatch($r))),
                ]),
            ])
            ->defaultSort('players_online', 'desc');
    }

    public static function getPages(): array
    {
        return [
            'index'  => Pages\ListServers::route('/'),
            'create' => Pages\CreateServer::route('/create'),
            'edit'   => Pages\EditServer::route('/{record}/edit'),
        ];
    }

    public static function getNavigationBadge(): ?string
    {
        return (string) Server::active()->online()->count();
    }
}
