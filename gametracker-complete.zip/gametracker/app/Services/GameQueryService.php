<?php

namespace App\Services;

use Exception;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class GameQueryService
{
    private string $apiUrl;
    private int    $timeout;

    public function __construct()
    {
        // URL catre query.php de pe hosting-ul tau
        $this->apiUrl  = config('gametracker.query_api_url', env('QUERY_API_URL', ''));
        $this->timeout = config('gametracker.query_timeout', 8);
    }

    /**
     * Query un server prin query.php API.
     * Returneaza array normalizat cu datele serverului.
     */
    public function query(string $ip, int $port): array
    {
        if (empty($this->apiUrl)) {
            throw new Exception('QUERY_API_URL nu este setat in .env. Pune query.php pe hosting si seteaza URL-ul.');
        }

        $response = Http::timeout($this->timeout)
            ->get($this->apiUrl, ['ip' => $ip, 'port' => $port]);

        if (!$response->successful()) {
            throw new Exception("query.php a returnat HTTP " . $response->status());
        }

        $data = $response->json();

        if (!is_array($data)) {
            throw new Exception("Raspuns invalid JSON de la query.php");
        }

        if (isset($data['error'])) {
            throw new Exception($data['error']);
        }

        return $this->normalize($data);
    }

    /**
     * Normalizeaza raspunsul de la query.php in formatul intern.
     */
    protected function normalize(array $raw): array
    {
        return [
            'online'             => (bool)($raw['online']             ?? false),
            'name'               => $this->sanitizeName($raw['name']  ?? ''),
            'game'               => $raw['game']                      ?? 'Unknown',
            'map'                => $raw['map']                       ?? null,
            'gamemode'           => $raw['gamemode']                  ?? null,
            'players_online'     => (int)($raw['players_online']      ?? 0),
            'players_max'        => (int)($raw['players_max']         ?? 0),
            'ping'               => (int)($raw['ping']                ?? 0),
            'version'            => $raw['version']                   ?? null,
            'password_protected' => (bool)($raw['password_protected'] ?? false),
            'vac'                => (bool)($raw['vac']                ?? false),
            'os'                 => $raw['os']                        ?? null,
            'players'            => array_map(fn($p) => [
                'name'  => $this->sanitizeName($p['name']  ?? 'Unknown'),
                'score' => (int)($p['score'] ?? 0),
                'time'  => (int)($p['time']  ?? 0),
            ], $raw['players'] ?? []),
        ];
    }

    /**
     * Sanitizeaza numele — sterge color codes, limiteaza lungimea.
     */
    public function sanitizeName(string $name): string
    {
        $name = preg_replace('/\^[0-9]/', '', $name);
        $name = preg_replace('/§[0-9a-fk-or]/i', '', $name);
        $name = strip_tags($name);
        return mb_substr(trim($name), 0, 64);
    }

    /**
     * Valideaza IP:port inainte de query.
     */
    public function validateAddress(string $ip, int $port): bool
    {
        return filter_var($ip, FILTER_VALIDATE_IP) !== false
            && $port >= 1
            && $port <= 65535;
    }
}
