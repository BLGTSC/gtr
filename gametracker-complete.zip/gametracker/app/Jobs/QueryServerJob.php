<?php

namespace App\Jobs;

use App\Models\Player;
use App\Models\PlayerSession;
use App\Models\Server;
use App\Models\ServerSnapshot;
use App\Services\GameQueryService;
use Exception;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class QueryServerJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $tries   = 2;
    public int $timeout = 30;

    public function __construct(public readonly Server $server)
    {
        $this->onQueue('queries');
    }

    public function handle(GameQueryService $service): void
    {
        if (!$this->server->is_active) return;

        try {
            $data = $service->query($this->server->ip, $this->server->port);
            $this->processSuccess($data);
        } catch (Exception $e) {
            $this->processFailure($e->getMessage());
        }
    }

    protected function processSuccess(array $data): void
    {
        DB::transaction(function () use ($data) {
            $this->server->markOnline($data);

            ServerSnapshot::create([
                'server_id'        => $this->server->id,
                'status'           => 'online',
                'players_online'   => $data['players_online'],
                'players_max'      => $data['players_max'],
                'ping'             => $data['ping'],
                'map'              => $data['map'],
                'gamemode'         => $data['gamemode'],
                'query_duration_ms'=> $data['ping'],
                'queried_at'       => now(),
            ]);

            if (!empty($data['players'])) {
                $this->trackPlayers($data['players'], $data['map']);
            }
        });
    }

    protected function trackPlayers(array $rawPlayers, ?string $map): void
    {
        foreach ($rawPlayers as $p) {
            if (empty(trim($p['name'] ?? ''))) continue;

            $player = Player::findOrCreateFromSession($this->server->id, $p['name']);
            $player->update(['last_seen_at' => now(), 'name' => $p['name']]);

            if (($p['score'] ?? 0) > $player->highest_score) {
                $player->update(['highest_score' => $p['score']]);
            }

            PlayerSession::firstOrCreate(
                ['player_id' => $player->id, 'server_id' => $this->server->id, 'is_active' => true],
                ['name_at_time' => $p['name'], 'map_at_time' => $map, 'started_at' => now()]
            )->update(['score' => $p['score'] ?? 0]);
        }
    }

    protected function processFailure(string $error): void
    {
        $this->server->markOffline($error);
        ServerSnapshot::create([
            'server_id'  => $this->server->id,
            'status'     => 'offline',
            'queried_at' => now(),
        ]);
        Log::warning("QueryServerJob failed for {$this->server->address}: {$error}");
    }
}
