<?php

namespace App\Http\Controllers;

use App\Jobs\QueryServerJob;
use App\Models\Game;
use App\Models\Server;
use App\Models\ServerSnapshot;
use App\Services\GameQueryService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ServerController extends Controller
{
    public function __construct(private GameQueryService $queryService) {}

    // Lista publica servere
    public function index(Request $request)
    {
        $games   = Game::active()->get();
        $query   = Server::active()->with('game')
            ->when($request->game,   fn($q) => $q->whereHas('game', fn($g) => $g->where('slug', $request->game)))
            ->when($request->search, fn($q) => $q->where('name', 'like', '%'.$request->search.'%'))
            ->when($request->status, fn($q) => $q->where('status', $request->status))
            ->orderByDesc('players_online')
            ->orderByDesc('is_featured');

        $servers = $query->paginate(50);
        return view('pages.servers.index', compact('servers', 'games'));
    }

    // Pagina server individual
    public function show(Server $server)
    {
        $server->load('game');
        $chartData = ServerSnapshot::hourlyAverages($server->id, 24);
        $topPlayers = $server->players()->orderByDesc('total_playtime_minutes')->limit(10)->get();
        return view('pages.servers.show', compact('server', 'chartData', 'topPlayers'));
    }

    // Formular adaugare server
    public function create()
    {
        $games = Game::active()->get();
        return view('pages.servers.create', compact('games'));
    }

    // Salveaza server nou
    public function store(Request $request)
    {
        $validated = $request->validate([
            'ip'   => 'required|ip',
            'port' => 'required|integer|min:1|max:65535',
            'name' => 'nullable|string|max:200',
        ]);

        $ip   = $validated['ip'];
        $port = (int)$validated['port'];

        // Verifica daca serverul exista deja
        if (Server::where('ip', $ip)->where('port', $port)->exists()) {
            return back()->withErrors(['ip' => 'Serverul este deja in lista!']);
        }

        // Query instant pentru a lua datele reale
        try {
            $data = $this->queryService->query($ip, $port);
        } catch (\Exception $e) {
            $data = ['online' => false, 'name' => $validated['name'] ?? "$ip:$port", 'game' => 'Unknown', 'map' => null, 'gamemode' => null, 'players_online' => 0, 'players_max' => 0, 'ping' => 0, 'version' => null, 'password_protected' => false, 'vac' => false, 'players' => []];
        }

        // Detecteaza jocul automat
        $game = Game::where('name', 'like', '%' . ($data['game'] ?? '') . '%')->first()
            ?? Game::where('protocol', 'goldsrc')->first()
            ?? Game::first();

        $server = Server::create([
            'game_id'        => $game?->id ?? 1,
            'user_id'        => Auth::id(),
            'name'           => $validated['name'] ?: ($data['name'] ?? "$ip:$port"),
            'ip'             => $ip,
            'port'           => $port,
            'status'         => $data['online'] ? 'online' : 'unknown',
            'map'            => $data['map']            ?? null,
            'gamemode'       => $data['gamemode']       ?? null,
            'players_online' => $data['players_online'] ?? 0,
            'players_max'    => $data['players_max']    ?? 0,
            'ping'           => $data['ping']           ?? null,
            'server_name'    => $data['name']           ?? null,
            'version'        => $data['version']        ?? null,
            'has_password'   => $data['password_protected'] ?? false,
            'vac'            => $data['vac']            ?? false,
            'is_active'      => true,
            'first_seen_at'  => now(),
            'last_queried_at'=> now(),
        ]);

        // Dispatch query job pentru a tine serverul actualizat
        QueryServerJob::dispatch($server);

        return redirect()->route('servers.show', $server->slug)
            ->with('success', 'Server adaugat cu succes!');
    }

    // API: date live pentru un server (folosit de widget Alpine.js)
    public function liveData(Server $server)
    {
        return response()->json([
            'status'         => $server->status,
            'players_online' => $server->players_online,
            'players_max'    => $server->players_max,
            'map'            => $server->map,
            'ping'           => $server->ping,
            'updated_at'     => $server->last_queried_at?->toIso8601String(),
        ]);
    }

    // API: date pentru grafic Chart.js
    public function chartData(Server $server, Request $request)
    {
        $hours = match($request->period) {
            '7d'   => 168,
            '30d'  => 720,
            default => 24,
        };

        $raw = ServerSnapshot::hourlyAverages($server->id, $hours);

        return response()->json([
            'labels' => array_column($raw, 'hour'),
            'values' => array_column($raw, 'avg_players'),
            'max'    => array_column($raw, 'max_players'),
        ]);
    }

    // API: query instant din browser (apeleaza query.php)
    public function queryInstant(Request $request)
    {
        $request->validate(['ip' => 'required|ip', 'port' => 'required|integer|min:1|max:65535']);

        try {
            $data = $this->queryService->query($request->ip, (int)$request->port);
            return response()->json(['success' => true, 'data' => $data]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()], 422);
        }
    }
}
