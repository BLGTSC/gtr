import './bootstrap';
import Alpine from 'alpinejs';
import Chart from 'chart.js/auto';
import ApexCharts from 'apexcharts';

window.Alpine   = Alpine;
window.Chart    = Chart;
window.ApexCharts = ApexCharts;

Alpine.start();

/**
 * Server live tracker component
 * Folosit pe pagina /servers/{slug}
 */
window.serverTracker = function(serverId, serverSlug) {
    return {
        status:        'unknown',
        playersOnline: 0,
        playersMax:    0,
        map:           '',
        ping:          0,
        chart:         null,
        pollInterval:  null,

        init() {
            this.initChart();
            this.startPolling();
        },

        async startPolling() {
            // Poll la fiecare 15 secunde pentru date live
            this.pollInterval = setInterval(() => this.fetchLive(), 15000);
        },

        async fetchLive() {
            try {
                const r = await fetch(`/api/servers/${serverSlug}/live`);
                const d = await r.json();
                this.status        = d.status;
                this.playersOnline = d.players_online;
                this.playersMax    = d.players_max;
                this.map           = d.map;
                this.ping          = d.ping;
            } catch(e) { console.error('Live fetch failed:', e); }
        },

        async initChart() {
            try {
                const r = await fetch(`/api/servers/${serverSlug}/chart?period=24h`);
                const d = await r.json();
                const ctx = document.getElementById('players-chart');
                if (!ctx) return;

                this.chart = new Chart(ctx, {
                    type: 'line',
                    data: {
                        labels: d.labels.map(l => l.slice(11, 16)), // HH:MM
                        datasets: [{
                            label: 'Jucatori online',
                            data: d.values,
                            borderColor: '#e8640c',
                            backgroundColor: 'rgba(232,100,12,0.1)',
                            fill: true,
                            tension: 0.4,
                            pointRadius: 2,
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: { legend: { display: false } },
                        scales: {
                            x: { grid: { color: '#1e2640' }, ticks: { color: '#6b7a9e', maxTicksLimit: 12 } },
                            y: { grid: { color: '#1e2640' }, ticks: { color: '#6b7a9e' }, min: 0 }
                        }
                    }
                });
            } catch(e) { console.error('Chart init failed:', e); }
        },

        destroy() {
            if (this.pollInterval) clearInterval(this.pollInterval);
            if (this.chart) this.chart.destroy();
        }
    };
};

/**
 * Query server component
 * Folosit pe pagina /add-server
 */
window.serverQuery = function(queryApiUrl) {
    return {
        ip:       '',
        port:     '27015',
        loading:  false,
        result:   null,
        error:    null,
        progress: 0,
        step:     '',

        async query() {
            if (!this.ip.trim()) { this.error = 'Introdu un IP valid!'; return; }
            this.loading = true;
            this.result  = null;
            this.error   = null;
            this.progress = 0;

            const steps = [
                { msg: `Conectare la ${this.ip}:${this.port}...`, pct: 20 },
                { msg: 'Handshake protocol UDP...',               pct: 45 },
                { msg: 'Citire informatii server...',             pct: 70 },
                { msg: 'Preluare lista jucatori...',              pct: 90 },
            ];

            // Simuleaza progres vizual
            for (const s of steps) {
                this.step     = s.msg;
                this.progress = s.pct;
                await new Promise(r => setTimeout(r, 300));
            }

            try {
                const r = await fetch('/api/query', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': document.querySelector('meta[name=csrf-token]').content },
                    body: JSON.stringify({ ip: this.ip, port: parseInt(this.port) })
                });
                const d = await r.json();
                if (d.success) {
                    this.result   = d.data;
                    this.progress = 100;
                    this.step     = 'Gata!';
                } else {
                    this.error = d.error || 'Eroare necunoscuta';
                }
            } catch(e) {
                this.error = 'Eroare de retea: ' + e.message;
            } finally {
                this.loading = false;
            }
        },

        formatTime(seconds) {
            if (seconds >= 3600) return Math.floor(seconds/3600) + 'h ' + Math.floor((seconds%3600)/60) + 'm';
            return Math.floor(seconds/60) + 'm';
        },

        get playersFillPct() {
            if (!this.result?.players_max) return 0;
            return Math.round(this.result.players_online / this.result.players_max * 100);
        }
    };
};
