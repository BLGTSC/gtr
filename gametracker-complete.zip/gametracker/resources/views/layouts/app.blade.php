<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}" class="dark">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ $title ?? config('app.name', 'GameTracker') }} — Monitorizare Servere Gaming</title>
    <meta name="description" content="{{ $description ?? 'Monitorizare în timp real pentru servere CS 1.6, CS2, Minecraft, Rust și altele.' }}">
    <meta property="og:title" content="{{ $title ?? config('app.name') }}">
    <meta property="og:description" content="{{ $description ?? '' }}">
    <meta property="og:type" content="website">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="min-h-screen" style="background:#0a0d14;color:#e2e8f0;font-family:'Exo 2',sans-serif">

    {{-- NAVBAR --}}
    <nav style="background:#0f1320;border-bottom:1px solid #1e2640;position:sticky;top:0;z-index:50">
        <div style="max-width:1280px;margin:0 auto;padding:0 16px;display:flex;align-items:center;justify-content:space-between;height:52px">

            {{-- Logo --}}
            <a href="{{ route('home') }}" style="font-family:'Rajdhani',sans-serif;font-size:22px;font-weight:700;color:#ff7a1a;letter-spacing:2px;text-decoration:none;display:flex;align-items:center;gap:8px">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" stroke="#e8640c" stroke-width="2" stroke-linecap="round"/></svg>
                GAME<span style="color:#e2e8f0">TRACKER</span>
            </a>

            {{-- Nav links (editabile din admin → settings) --}}
            <div style="display:flex;gap:2px">
                @php $navLinks = \App\Models\Setting::getNavLinks(); @endphp
                @foreach($navLinks as $link)
                    <a href="{{ $link['url'] }}"
                       style="padding:6px 12px;color:#6b7a9e;font-size:13px;font-weight:600;text-decoration:none;border-radius:4px;text-transform:uppercase;letter-spacing:.5px;transition:color .15s"
                       onmouseover="this.style.color='#e2e8f0'" onmouseout="this.style.color='#6b7a9e'">
                        {{ $link['label'] }}
                    </a>
                @endforeach
            </div>

            {{-- Right --}}
            <div style="display:flex;gap:8px;align-items:center">
                <a href="{{ route('servers.create') }}" style="background:#e8640c;color:#fff;padding:6px 14px;border-radius:4px;font-size:13px;font-weight:700;text-decoration:none">+ Adaugă Server</a>
                @auth
                    <a href="/admin" style="background:transparent;border:1px solid #252d45;color:#e2e8f0;padding:6px 14px;border-radius:4px;font-size:13px;font-weight:600;text-decoration:none">Admin</a>
                @else
                    <a href="{{ route('login') }}" style="background:transparent;border:1px solid #252d45;color:#6b7a9e;padding:6px 14px;border-radius:4px;font-size:13px;font-weight:600;text-decoration:none">Login</a>
                @endauth
            </div>
        </div>
    </nav>

    {{-- Flash messages --}}
    @if(session('success'))
        <div style="background:rgba(34,197,94,.1);border:1px solid rgba(34,197,94,.25);color:#4ade80;padding:10px 16px;text-align:center;font-size:13px">
            {{ session('success') }}
        </div>
    @endif

    {{-- Content --}}
    <main>{{ $slot }}</main>

    {{-- Footer --}}
    <footer style="border-top:1px solid #1e2640;padding:24px 16px;text-align:center;color:#4a5568;font-size:12px;margin-top:48px">
        <div style="max-width:1280px;margin:0 auto;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px">
            <span>© {{ date('Y') }} GameTracker — Monitorizare servere gaming în timp real</span>
            <div style="display:flex;gap:16px">
                <a href="/sitemap.xml" style="color:#4a5568;text-decoration:none">Sitemap</a>
                <a href="/privacy" style="color:#4a5568;text-decoration:none">Privacy</a>
            </div>
        </div>
    </footer>

</body>
</html>
