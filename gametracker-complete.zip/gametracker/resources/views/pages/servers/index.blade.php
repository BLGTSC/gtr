<x-app-layout>
<x-slot name="title">Servere Gaming</x-slot>

{{-- HERO --}}
<div style="background:#0f1320;border-bottom:1px solid #1e2640;padding:28px 0">
    <div style="max-width:1280px;margin:0 auto;padding:0 16px;display:flex;align-items:center;justify-content:space-between;gap:24px;flex-wrap:wrap">
        <div>
            <h1 style="font-family:'Rajdhani',sans-serif;font-size:32px;font-weight:700;margin-bottom:6px">
                Servere <span style="color:#ff7a1a">Multiplayer</span>
            </h1>
            <p style="color:#6b7a9e;font-size:14px">Monitorizare în timp real — {{ \App\Models\Server::active()->count() }} servere înregistrate</p>
        </div>
        <div style="display:flex;gap:20px">
            <div style="text-align:center">
                <div style="font-family:'Rajdhani',sans-serif;font-size:28px;font-weight:700;color:#ff7a1a">{{ \App\Models\Server::active()->online()->count() }}</div>
                <div style="font-size:11px;color:#6b7a9e;text-transform:uppercase;letter-spacing:1px">Online</div>
            </div>
            <div style="text-align:center">
                <div style="font-family:'Rajdhani',sans-serif;font-size:28px;font-weight:700;color:#22c55e">{{ \App\Models\Server::active()->online()->sum('players_online') }}</div>
                <div style="font-size:11px;color:#6b7a9e;text-transform:uppercase;letter-spacing:1px">Jucători</div>
            </div>
        </div>
    </div>
</div>

{{-- FILTERS --}}
<div style="background:#0f1320;border-bottom:1px solid #1e2640">
    <div style="max-width:1280px;margin:0 auto;padding:0 16px;display:flex;gap:0;overflow-x:auto">
        <a href="{{ route('servers.index') }}"
           style="padding:12px 16px;color:{{ !request('game') ? '#ff7a1a' : '#6b7a9e' }};font-size:13px;font-weight:600;text-decoration:none;border-bottom:2px solid {{ !request('game') ? '#e8640c' : 'transparent' }};white-space:nowrap;text-transform:uppercase;letter-spacing:.5px">
            Toate
        </a>
        @foreach($games as $game)
            <a href="{{ route('servers.index', ['game' => $game->slug]) }}"
               style="padding:12px 16px;color:{{ request('game') === $game->slug ? '#ff7a1a' : '#6b7a9e' }};font-size:13px;font-weight:600;text-decoration:none;border-bottom:2px solid {{ request('game') === $game->slug ? '#e8640c' : 'transparent' }};white-space:nowrap;text-transform:uppercase;letter-spacing:.5px">
                {{ $game->short_name }}
            </a>
        @endforeach
    </div>
</div>

{{-- SEARCH --}}
<div style="max-width:1280px;margin:16px auto;padding:0 16px">
    <form method="GET" style="display:flex;gap:10px">
        @if(request('game'))<input type="hidden" name="game" value="{{ request('game') }}">@endif
        <input type="text" name="search" value="{{ request('search') }}"
               placeholder="Cauta server dupa nume..."
               style="flex:1;background:#161c2e;border:1px solid #252d45;border-radius:4px;padding:9px 14px;color:#e2e8f0;font-size:14px;font-family:'Exo 2',sans-serif;outline:none;max-width:400px">
        <button type="submit" style="background:#e8640c;color:#fff;border:none;border-radius:4px;padding:9px 20px;font-size:13px;font-weight:700;cursor:pointer;font-family:'Exo 2',sans-serif">Caută</button>
        @if(request('search') || request('game'))
            <a href="{{ route('servers.index') }}" style="background:transparent;border:1px solid #252d45;color:#6b7a9e;border-radius:4px;padding:9px 14px;font-size:13px;font-weight:600;text-decoration:none;display:flex;align-items:center">✕ Reset</a>
        @endif
    </form>
</div>

{{-- SERVER TABLE --}}
<div style="max-width:1280px;margin:0 auto;padding:0 16px 32px">
    <div style="background:#161c2e;border:1px solid #1e2640;border-radius:6px;overflow:hidden">

        {{-- Table header --}}
        <div style="display:grid;grid-template-columns:40px 1fr 110px 130px 70px 70px 60px;gap:8px;padding:10px 14px;background:#0f1320;border-bottom:1px solid #1e2640;font-size:11px;text-transform:uppercase;letter-spacing:1px;color:#4a5568;font-weight:700">
            <div>#</div><div>Server</div><div>Jucători</div><div>Hartă</div><div>Ping</div><div>Voturi</div><div>Status</div>
        </div>

        @forelse($servers as $i => $server)
            <a href="{{ route('servers.show', $server->slug) }}" style="display:grid;grid-template-columns:40px 1fr 110px 130px 70px 70px 60px;gap:8px;padding:10px 14px;border-bottom:1px solid #1e2640;align-items:center;text-decoration:none;transition:background .1s" onmouseover="this.style.background='#1a2035'" onmouseout="this.style.background='transparent'">

                {{-- Rank --}}
                <div style="font-family:'Rajdhani',sans-serif;font-size:17px;font-weight:700;color:{{ $i < 3 ? '#ff7a1a' : '#4a5568' }};text-align:center">
                    {{ $servers->firstItem() + $i }}
                </div>

                {{-- Info --}}
                <div>
                    <div style="font-weight:700;font-size:13px;color:#e2e8f0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:320px">
                        @if($server->is_featured) <span style="color:#ff7a1a;font-size:10px;margin-right:4px">★</span> @endif
                        {{ $server->name }}
                    </div>
                    <div style="display:flex;align-items:center;gap:8px;margin-top:2px">
                        <span style="font-family:monospace;font-size:11px;color:#4a5568;background:#0f1320;padding:1px 5px;border-radius:3px;border:1px solid #1e2640">{{ $server->ip }}:{{ $server->port }}</span>
                        <span style="font-size:11px;color:#4a5568">{{ $server->game->short_name }}</span>
                    </div>
                </div>

                {{-- Players --}}
                @php $pct = $server->players_max > 0 ? round($server->players_online/$server->players_max*100) : 0; @endphp
                <div>
                    <div style="font-family:'Rajdhani',sans-serif;font-size:15px;font-weight:700;color:{{ $pct > 85 ? '#ef4444' : ($pct > 50 ? '#ff7a1a' : '#22c55e') }}">
                        {{ $server->players_online }}/{{ $server->players_max }}
                    </div>
                    <div style="height:3px;background:#252d45;border-radius:2px;margin-top:3px">
                        <div style="height:100%;width:{{ $pct }}%;background:{{ $pct > 85 ? '#ef4444' : ($pct > 50 ? '#e8640c' : '#22c55e') }};border-radius:2px"></div>
                    </div>
                </div>

                {{-- Map --}}
                <div style="font-size:12px;color:#6b7a9e;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">{{ $server->map ?? '—' }}</div>

                {{-- Ping --}}
                <div style="font-family:'Rajdhani',sans-serif;font-size:14px;font-weight:700;color:{{ $server->ping < 30 ? '#22c55e' : ($server->ping < 70 ? '#ff7a1a' : '#ef4444') }}">
                    {{ $server->ping ? $server->ping.'ms' : '—' }}
                </div>

                {{-- Votes (placeholder) --}}
                <div style="font-size:12px;color:#6b7a9e;text-align:center">▲ 0</div>

                {{-- Status --}}
                <div>
                    <span style="display:inline-block;width:9px;height:9px;border-radius:50%;background:{{ $server->status === 'online' ? '#22c55e' : ($server->status === 'offline' ? '#ef4444' : '#f59e0b') }}"></span>
                </div>

            </a>
        @empty
            <div style="padding:40px;text-align:center;color:#4a5568;font-style:italic">Niciun server găsit.</div>
        @endforelse
    </div>

    {{-- Pagination --}}
    <div style="margin-top:16px">{{ $servers->links() }}</div>
</div>

</x-app-layout>
