<x-app-layout>
<x-slot name="title">{{ $server->name }}</x-slot>
<x-slot name="description">Server {{ $server->game->name }} — {{ $server->ip }}:{{ $server->port }} — {{ $server->players_online }}/{{ $server->players_max }} jucători online pe {{ $server->map }}</x-slot>

<div x-data="serverTracker({{ $server->id }}, '{{ $server->slug }}')" x-init="init()" style="max-width:1280px;margin:0 auto;padding:24px 16px">

    {{-- HEADER --}}
    <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:16px;flex-wrap:wrap;margin-bottom:24px">
        <div>
            <div style="display:flex;align-items:center;gap:10px;margin-bottom:6px">
                <span :class="status === 'online' ? 'badge-online' : 'badge-offline'" style="display:inline-flex;align-items:center;gap:4px;padding:3px 10px;border-radius:20px;font-size:11px;font-weight:700">
                    <span :style="status === 'online' ? 'background:#22c55e' : 'background:#ef4444'" style="width:7px;height:7px;border-radius:50%;display:inline-block"></span>
                    <span x-text="status === 'online' ? 'ONLINE' : 'OFFLINE'"></span>
                </span>
                <span style="font-size:12px;color:#4a5568">{{ $server->game->name }}</span>
                @if($server->vac)<span style="background:rgba(59,130,246,.15);color:#93c5fd;font-size:11px;font-weight:700;padding:2px 8px;border-radius:3px">✔ VAC</span>@endif
                @if($server->has_password)<span style="background:rgba(239,68,68,.15);color:#f87171;font-size:11px;font-weight:700;padding:2px 8px;border-radius:3px">🔒 Parolat</span>@endif
            </div>
            <h1 style="font-family:'Rajdhani',sans-serif;font-size:26px;font-weight:700;margin-bottom:4px">{{ $server->name }}</h1>
            <code style="font-size:13px;color:#6b7a9e;background:#0f1320;padding:3px 8px;border-radius:4px;border:1px solid #1e2640">{{ $server->address }}</code>
        </div>
        <a href="{{ route('servers.index') }}" style="color:#6b7a9e;font-size:13px;text-decoration:none;border:1px solid #1e2640;padding:6px 12px;border-radius:4px">← Înapoi</a>
    </div>

    {{-- STATS GRID --}}
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:12px;margin-bottom:24px">
        <div style="background:#161c2e;border:1px solid #1e2640;border-radius:6px;padding:14px;text-align:center">
            <div style="font-size:10px;text-transform:uppercase;letter-spacing:1px;color:#4a5568;margin-bottom:4px;font-weight:700">JUCĂTORI</div>
            <div x-text="playersOnline + '/' + playersMax" style="font-family:'Rajdhani',sans-serif;font-size:28px;font-weight:700;color:#ff7a1a">{{ $server->players_online }}/{{ $server->players_max }}</div>
        </div>
        <div style="background:#161c2e;border:1px solid #1e2640;border-radius:6px;padding:14px;text-align:center">
            <div style="font-size:10px;text-transform:uppercase;letter-spacing:1px;color:#4a5568;margin-bottom:4px;font-weight:700">PING</div>
            <div x-text="ping + 'ms'" style="font-family:'Rajdhani',sans-serif;font-size:28px;font-weight:700;color:#22c55e">{{ $server->ping }}ms</div>
        </div>
        <div style="background:#161c2e;border:1px solid #1e2640;border-radius:6px;padding:14px;text-align:center">
            <div style="font-size:10px;text-transform:uppercase;letter-spacing:1px;color:#4a5568;margin-bottom:4px;font-weight:700">HARTĂ</div>
            <div x-text="map" style="font-family:'Rajdhani',sans-serif;font-size:18px;font-weight:700;color:#3b82f6">{{ $server->map ?? '—' }}</div>
        </div>
        <div style="background:#161c2e;border:1px solid #1e2640;border-radius:6px;padding:14px;text-align:center">
            <div style="font-size:10px;text-transform:uppercase;letter-spacing:1px;color:#4a5568;margin-bottom:4px;font-weight:700">UPTIME 30 ZILE</div>
            <div style="font-family:'Rajdhani',sans-serif;font-size:28px;font-weight:700;color:#22c55e">{{ number_format($server->uptime_percentage, 1) }}%</div>
        </div>
        <div style="background:#161c2e;border:1px solid #1e2640;border-radius:6px;padding:14px;text-align:center">
            <div style="font-size:10px;text-transform:uppercase;letter-spacing:1px;color:#4a5568;margin-bottom:4px;font-weight:700">PEAK PLAYERS</div>
            <div style="font-family:'Rajdhani',sans-serif;font-size:28px;font-weight:700;color:#f59e0b">{{ $server->peak_players }}</div>
        </div>
    </div>

    <div style="display:grid;grid-template-columns:1fr 340px;gap:20px;align-items:start">

        {{-- LEFT: Chart + Players --}}
        <div>
            {{-- Chart --}}
            <div style="background:#161c2e;border:1px solid #1e2640;border-radius:6px;padding:16px;margin-bottom:16px">
                <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px">
                    <div style="font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:#6b7a9e">Jucători online — ultimele 24h</div>
                    <div style="display:flex;gap:6px">
                        <button onclick="changeChartPeriod('24h')" style="background:#e8640c;color:#fff;border:none;padding:3px 10px;border-radius:3px;font-size:11px;font-weight:700;cursor:pointer">24h</button>
                        <button onclick="changeChartPeriod('7d')"  style="background:transparent;border:1px solid #252d45;color:#6b7a9e;padding:3px 10px;border-radius:3px;font-size:11px;font-weight:700;cursor:pointer">7 zile</button>
                        <button onclick="changeChartPeriod('30d')" style="background:transparent;border:1px solid #252d45;color:#6b7a9e;padding:3px 10px;border-radius:3px;font-size:11px;font-weight:700;cursor:pointer">30 zile</button>
                    </div>
                </div>
                <div style="height:180px"><canvas id="players-chart"></canvas></div>
            </div>

            {{-- Top Players --}}
            <div style="background:#161c2e;border:1px solid #1e2640;border-radius:6px;padding:16px">
                <div style="font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:#6b7a9e;margin-bottom:12px">Top Jucători</div>
                @forelse($topPlayers as $i => $player)
                    <div style="display:flex;align-items:center;gap:12px;padding:8px 0;border-bottom:1px solid #1e2640">
                        <span style="font-family:'Rajdhani',sans-serif;font-size:18px;font-weight:700;color:{{ $i < 3 ? '#ff7a1a' : '#4a5568' }};width:24px;text-align:center">{{ $i+1 }}</span>
                        <span style="flex:1;font-weight:600;font-size:13px">{{ $player->name }}</span>
                        <span style="font-size:12px;color:#6b7a9e">{{ $player->playtime_formatted }}</span>
                        <span style="font-family:'Rajdhani',sans-serif;font-size:14px;font-weight:700;color:#ff7a1a">{{ $player->highest_score }}pt</span>
                    </div>
                @empty
                    <p style="color:#4a5568;font-size:13px;font-style:italic">Niciun jucător înregistrat.</p>
                @endforelse
            </div>
        </div>

        {{-- RIGHT: Info card --}}
        <div>
            <div style="background:#161c2e;border:1px solid #1e2640;border-radius:6px;padding:16px">
                <div style="font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:#6b7a9e;margin-bottom:12px">Informații server</div>
                @foreach([
                    ['IP',       $server->ip],
                    ['Port',     $server->port],
                    ['Mod',      $server->gamemode],
                    ['Versiune', $server->version],
                    ['OS',       $server->extra_info['os'] ?? 'Linux'],
                    ['Adăugat',  $server->first_seen_at?->diffForHumans()],
                    ['Ultima verificare', $server->last_queried_at?->diffForHumans()],
                ] as [$label, $value])
                    @if($value)
                    <div style="display:flex;justify-content:space-between;padding:7px 0;border-bottom:1px solid #1e2640;font-size:13px">
                        <span style="color:#6b7a9e">{{ $label }}</span>
                        <span style="font-weight:600">{{ $value }}</span>
                    </div>
                    @endif
                @endforeach
            </div>

            {{-- Connect button --}}
            <div style="background:#161c2e;border:1px solid #1e2640;border-radius:6px;padding:14px;margin-top:12px;text-align:center">
                <div style="font-size:11px;color:#4a5568;margin-bottom:8px;text-transform:uppercase;letter-spacing:1px">Conectare directă</div>
                <code style="background:#0f1320;border:1px solid #1e2640;padding:8px 12px;border-radius:4px;font-size:13px;display:block;margin-bottom:10px;color:#ff7a1a">connect {{ $server->address }}</code>
                <button onclick="navigator.clipboard.writeText('connect {{ $server->address }}')"
                    style="background:#e8640c;color:#fff;border:none;padding:8px 20px;border-radius:4px;font-size:13px;font-weight:700;cursor:pointer;width:100%;font-family:'Exo 2',sans-serif">
                    📋 Copiază adresa
                </button>
            </div>
        </div>
    </div>
</div>

<script>
function changeChartPeriod(period) {
    // Re-fetch chart cu noua perioada
    fetch(`/api/servers/{{ $server->slug }}/chart?period=${period}`)
        .then(r => r.json())
        .then(d => {
            const chart = Chart.getChart('players-chart');
            if (chart) {
                chart.data.labels = d.labels.map(l => l.slice(11,16));
                chart.data.datasets[0].data = d.values;
                chart.update();
            }
        });
}
</script>

</x-app-layout>
