<x-app-layout>
<x-slot name="title">Adaugă Server</x-slot>

<div style="max-width:640px;margin:40px auto;padding:0 16px">

    <h1 style="font-family:'Rajdhani',sans-serif;font-size:26px;font-weight:700;margin-bottom:4px">
        Adaugă Server <span style="color:#ff7a1a">Gaming</span>
    </h1>
    <p style="color:#6b7a9e;font-size:13px;margin-bottom:24px">Introdu IP-ul și portul — datele sunt preluate automat prin query live.</p>

    {{-- Alpine.js query component --}}
    <div x-data="serverQuery('{{ route('api.query') }}')" style="background:#161c2e;border:1px solid #1e2640;border-radius:6px;padding:24px">

        {{-- IP + PORT --}}
        <div style="display:flex;gap:12px;margin-bottom:16px">
            <div style="flex:1">
                <label style="display:block;font-size:10px;text-transform:uppercase;letter-spacing:.8px;color:#6b7a9e;margin-bottom:5px;font-weight:700">Adresă IP</label>
                <input x-model="ip" type="text" placeholder="ex: 89.42.132.29"
                       @keydown.enter="query()"
                       style="width:100%;background:#0f1320;border:1px solid #252d45;border-radius:4px;padding:9px 12px;color:#e2e8f0;font-size:14px;font-family:'Exo 2',sans-serif;outline:none"
                       :style="{ borderColor: error ? '#ef4444' : '' }">
            </div>
            <div style="width:110px">
                <label style="display:block;font-size:10px;text-transform:uppercase;letter-spacing:.8px;color:#6b7a9e;margin-bottom:5px;font-weight:700">Port</label>
                <input x-model="port" type="text"
                       style="width:100%;background:#0f1320;border:1px solid #252d45;border-radius:4px;padding:9px 12px;color:#e2e8f0;font-size:14px;font-family:'Exo 2',sans-serif;outline:none">
            </div>
        </div>

        {{-- QUERY BUTTON --}}
        <button @click="query()" :disabled="loading"
                style="width:100%;background:#e8640c;color:#fff;border:none;border-radius:4px;padding:10px;font-size:14px;font-weight:700;cursor:pointer;font-family:'Exo 2',sans-serif;margin-bottom:16px"
                :style="{ opacity: loading ? .6 : 1 }">
            <span x-show="!loading">🔍 Query Server Live</span>
            <span x-show="loading" x-text="step">Se conectează...</span>
        </button>

        {{-- PROGRESS --}}
        <div x-show="loading" style="margin-bottom:16px">
            <div style="height:4px;background:#252d45;border-radius:2px;overflow:hidden">
                <div :style="{ width: progress + '%' }" style="height:100%;background:#e8640c;border-radius:2px;transition:width .3s"></div>
            </div>
        </div>

        {{-- ERROR --}}
        <div x-show="error" style="background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.25);color:#f87171;padding:10px 14px;border-radius:4px;font-size:13px;margin-bottom:16px">
            ❌ <span x-text="error"></span>
        </div>

        {{-- RESULT --}}
        <div x-show="result" style="background:#0f1320;border:1px solid #1e2640;border-radius:4px;padding:16px;margin-bottom:16px">
            <div style="display:flex;align-items:center;gap:8px;margin-bottom:12px">
                <span style="width:9px;height:9px;border-radius:50%;background:#22c55e;display:inline-block"></span>
                <span style="font-weight:700;color:#22c55e;font-size:14px">Server online — date preluate</span>
            </div>

            <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:12px">
                <template x-for="[label, val] in [
                    ['Nume server', result?.name],
                    ['Joc',         result?.game],
                    ['Hartă',       result?.map],
                    ['Mod',         result?.gamemode],
                    ['Versiune',    result?.version],
                    ['Securitate',  (result?.vac ? '✔ VAC' : 'No VAC') + (result?.password_protected ? ' 🔒' : '')]
                ]">
                    <div>
                        <div style="font-size:10px;text-transform:uppercase;letter-spacing:.7px;color:#4a5568;margin-bottom:2px;font-weight:700" x-text="label"></div>
                        <div style="font-family:'Rajdhani',sans-serif;font-size:15px;font-weight:700" x-text="val"></div>
                    </div>
                </template>
                <div>
                    <div style="font-size:10px;text-transform:uppercase;letter-spacing:.7px;color:#4a5568;margin-bottom:2px;font-weight:700">Jucători</div>
                    <div :style="{ color: playersFillPct > 85 ? '#ef4444' : (playersFillPct > 50 ? '#ff7a1a' : '#22c55e') }"
                         style="font-family:'Rajdhani',sans-serif;font-size:22px;font-weight:700"
                         x-text="(result?.players_online ?? 0) + '/' + (result?.players_max ?? 0)"></div>
                </div>
                <div>
                    <div style="font-size:10px;text-transform:uppercase;letter-spacing:.7px;color:#4a5568;margin-bottom:2px;font-weight:700">Ping</div>
                    <div :style="{ color: (result?.ping ?? 0) < 30 ? '#22c55e' : (result?.ping < 70 ? '#ff7a1a' : '#ef4444') }"
                         style="font-family:'Rajdhani',sans-serif;font-size:22px;font-weight:700"
                         x-text="(result?.ping ?? 0) + 'ms'"></div>
                </div>
            </div>

            {{-- Players list --}}
            <div x-show="result?.players?.length > 0" style="background:#161c2e;border:1px solid #1e2640;border-radius:4px;padding:10px">
                <div style="font-size:10px;text-transform:uppercase;letter-spacing:.7px;color:#4a5568;margin-bottom:8px;font-weight:700">Jucători activi</div>
                <div style="display:flex;flex-wrap:wrap;gap:4px">
                    <template x-for="p in result?.players?.slice(0,15)" :key="p.name">
                        <span style="display:inline-flex;align-items:center;gap:4px;background:#1a2035;border:1px solid #1e2640;border-radius:3px;padding:3px 8px;font-size:12px">
                            👤 <span x-text="p.name"></span>
                            <span style="color:#ff7a1a;font-weight:700;font-size:11px" x-text="p.score + 'pt'"></span>
                            <span style="color:#4a5568;font-size:10px" x-text="formatTime(p.time)"></span>
                        </span>
                    </template>
                </div>
            </div>
        </div>

        {{-- FORM SUBMIT --}}
        <form x-show="result" method="POST" action="{{ route('servers.store') }}">
            @csrf
            <input type="hidden" name="ip"   :value="ip">
            <input type="hidden" name="port" :value="port">
            <div style="margin-bottom:12px">
                <label style="display:block;font-size:10px;text-transform:uppercase;letter-spacing:.8px;color:#6b7a9e;margin-bottom:5px;font-weight:700">Nume afișat (opțional)</label>
                <input type="text" name="name" :placeholder="result?.name ?? 'Lasă gol pentru numele serverului'"
                       style="width:100%;background:#0f1320;border:1px solid #252d45;border-radius:4px;padding:9px 12px;color:#e2e8f0;font-size:14px;font-family:'Exo 2',sans-serif;outline:none">
            </div>
            <button type="submit"
                    style="width:100%;background:#15803d;color:#fff;border:none;border-radius:4px;padding:10px;font-size:14px;font-weight:700;cursor:pointer;font-family:'Exo 2',sans-serif">
                ✅ Adaugă serverul la listă
            </button>
        </form>

    </div>
</div>

</x-app-layout>
